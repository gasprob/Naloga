<?php
	//v spremenljivko shranim URL naslov
	$url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
	/*
	echo $url;
	echo '<br>';
	
	
	*/
	//string obrnem, da dobim obrnjeno vneseno besedo
	$rev= strrev($url);
	//echo '<br>';
	$i=0;
	//v novo tabelo shranjujem vse znake do prvega /
	$pom=array();
	$tab= array($rev);
		foreach($tab as $t)
		{
			while($t[$i]!="/")
			{
				//print_r ($t[$i]);
				array_push($pom, $t[$i]);
				$i++;
				
			}
		
		}
	//echo '<br>';
	/*echo implode("", $pom);
	echo '<br>';
	$pravilno= array();
	$pravilno= print_r (array_reverse($pom));
	
	//echo json_encode($pom);
	echo '<br>';
	echo "{input:".print_r ($pom)."reversed:".implode("", $pom)."}";
	*/
	//echo implode("", $pom);
	//echo json_encode($pom);
	
	//tukaj tabelo obrem, da dobim originalno vneseno besedo
	$rez= array_reverse($pom);
	//print_r($rez);
	
	//uporabim funkcijo json_encode, s katero "parsam" podatkovi tip array v string, za uporabo funkcije implode
	json_encode($rez);
	//echo implode("", $rez);
	//echo implode("", $rez);
	
	//na koncu sparsam se niz, v obliki JSON-a
	echo  '{input: "'.implode("", $rez).'"reversed: "'.implode("", $pom).'"}';

?>